import 'package:flutter/material.dart';
import 'package:assignment_03/Product.dart';

class rowCounter extends StatefulWidget {
  const rowCounter(
      {Key? key,
        required this.productList,
        required this.index,
        required this.selectedProducts,
        required this.onPress
      })
      : super(key: key);
  final int index;
  final List<Product> productList;
  final List<Product>selectedProducts;
  final VoidCallback onPress;


  @override
  State<rowCounter> createState() => _rowCounterState();
}

class _rowCounterState extends State<rowCounter> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage(widget.productList[widget.index].ImageURL),
        ),
        title: Text(widget.productList[widget.index].productName),
        trailing: (widget.productList[widget.index].isSelected == false
            ? IconButton(
            onPressed: () {
              widget.onPress();
              setState(() {
                widget.productList[widget.index].isSelected = true;
                widget.productList[widget.index].productQuantity++;
                widget.selectedProducts.add(widget.productList[widget.index]);
                print(widget.selectedProducts.toString());

              });
            },
            icon: Icon(Icons.add))
            : Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              onPressed: () {
                setState(() {
                  widget.productList[widget.index].incrementProduct(
                      widget.productList[widget.index]);
                });

                //print(productList[index].productQuantity);
              },
              icon: Icon(Icons.add_circle),
            ),
            Text(widget.productList[widget.index].productQuantity
                .toString()),
            IconButton(
              onPressed: () {
                widget.onPress();
                setState(() {
                  if (widget.productList[widget.index].productQuantity ==
                      1) {
                    widget.productList[widget.index].isSelected = false;
                    widget.productList[widget.index].productQuantity--;
                    widget.selectedProducts.remove(widget.productList[widget.index]);

                  } else {
                    widget.productList[widget.index].decrementProduct(
                        widget.productList[widget.index]);

                  }
                });

                //print(productList[index].productQuantity);
              },
              icon: Icon(Icons.remove_circle),
            ),
          ],
        )));
  }
}
