class Product {
  final String productName;
  int productQuantity;
  bool isSelected;
  String ImageURL;

  Product({
    required this.productName,
    required this.productQuantity,
    required this.isSelected,
    required this.ImageURL,
  });

  void incrementProduct(Product product) {
    product.productQuantity++;

    ;
  }

  void decrementProduct(Product product) {
    if (product.productQuantity > 1) {
      product.productQuantity--;
    } else {
      if (product.productQuantity == 1) {
        product.isSelected = false;
        product.productQuantity--;
      }
    }
  }
}
