import 'package:flutter/material.dart';
import 'package:assignment_03/rowCounter.dart';
import 'package:assignment_03/Product.dart';
import 'package:assignment_03/screen2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Assignment 03',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Product> productList = [
    Product(
      productName: "Coca Cola",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "CocaCola.jpeg",
    ),
    Product(
      productName: "Sprite",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "Sprite.jpeg",
    ),
    Product(
      productName: "Pepsi",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "Pepsi.jpeg",
    ),
    Product(
      productName: "7up",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "7up.jpeg",
    ),
    Product(
      productName: "Aquafina",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "Aquafina.jpeg",
    ),
    Product(
      productName: "Mirinda",
      productQuantity: 0,
      isSelected: false,
      ImageURL: "Mirinda.jpeg",
    )

  ];
  List<Product> selectedProducts = [];
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(
          "Beverages",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
      ),
      body: ListView.builder(
        itemBuilder: (BuildContext, index) {
          return Card(
            child: rowCounter(
              productList: productList,
              index: index,
              selectedProducts: selectedProducts,
              onPress: (){
                setState(() {

                });
              },

            ),
          );
        },
        shrinkWrap: true,
        itemCount: productList.length,
        padding: EdgeInsets.all(10),

      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context)=> screen2(selectedProduct: selectedProducts,onPress: (){
            setState(() {

            });
          },)));
        },
        child: Text("Go to Cart(" + selectedProducts.length.toString() + ")",style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(18.0)),
        ),
    )
    );
  }
}




