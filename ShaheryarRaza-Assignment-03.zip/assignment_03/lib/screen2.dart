import 'package:flutter/material.dart';
import 'package:assignment_03/Product.dart';

class screen2 extends StatefulWidget {
  const screen2({Key? key, required this.selectedProduct,required this.onPress}) : super(key: key);
  final List<Product>selectedProduct;
  final VoidCallback onPress;

  @override
  State<screen2> createState() => _screen2State();
}

class _screen2State extends State<screen2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cart",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
      ),
      body: ListView.builder(
        itemBuilder: (BuildContext, index) {
          return Card(
            child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage(widget.selectedProduct[index].ImageURL),
                ),
                title: Text(widget.selectedProduct[index].productName),

                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      onPressed: () {
                        widget.onPress();
                        setState(() {
                          widget.selectedProduct[index].incrementProduct(
                              widget.selectedProduct[index]);
                        });

                        //print(productList[index].productQuantity);
                      },
                      icon: Icon(Icons.add_circle),
                    ),
                    Text(widget.selectedProduct[index].productQuantity
                        .toString()),
                    IconButton(
                      onPressed: () {
                        widget.onPress();
                        setState(() {
                          if (widget.selectedProduct[index].productQuantity ==
                              1) {
                            widget.selectedProduct[index].isSelected = false;
                            widget.selectedProduct[index].productQuantity--;
                            widget.selectedProduct.remove(
                                widget.selectedProduct[index]);
                          } else {
                            widget.selectedProduct[index].decrementProduct(
                                widget.selectedProduct[index]);
                          }
                        });

                        //print(productList[index].productQuantity);
                      },
                      icon: Icon(Icons.remove_circle),
                    ),
                  ],
                )


            ),
          );
        },
        shrinkWrap: true,
        itemCount: widget.selectedProduct.length,
        padding: EdgeInsets.all(10),

      )
    );
  }
}
